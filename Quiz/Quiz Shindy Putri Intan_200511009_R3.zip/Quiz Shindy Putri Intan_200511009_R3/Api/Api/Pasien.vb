﻿Public Class Pasien
    Public Property ip As String
    Public Property nrp As String
    Public Property nama As String
    Public Property jk As String
    Public Property tgl_lahir As String
    Public Property alamat As String
    Public Property kota As String
End Class
