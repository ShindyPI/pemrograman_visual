-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2023 at 02:31 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rawatinapapi`
--

-- --------------------------------------------------------

--
-- Table structure for table `pasien`
--
CREATE TABLE pasien (
    `Noreg` VARCHAR(20) NOT NULL,
    `NamaPasien` VARCHAR(100) NOT NULL,
    `TmptLahir` VARCHAR(100) NOT NULL,
    `Usia` INT,
    `NoTelpon` VARCHAR(20)  NOT NULL,
    `Alamat` VARCHAR(200)  NOT NULL,
    `TanggalLahir` date NOT NULL,
    `TglMasuk` date NOT NULL,
    `Agama` VARCHAR(50)  NOT NULL,
    `Jkelamin` enum('L','P') NOT NULL DEFAULT 'L',
    `RuangPerawatan` VARCHAR(100),
    `KlsPerawatan` VARCHAR(100),
    `Pembayaran` VARCHAR(50),
    `DrPJawab` VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pasien`
--
INSERT INTO pasien (`id`,`Noreg`, `NamaPasien`, `TmptLahir`, `Usia`, `NoTelpon`, `Alamat`, `TanggalLahir`, `TglMasuk`, `Agama`, `Jkelamin`, `RuangPerawatan`, `KlsPerawatan`, `Pembayaran`, `DrPJawab`) VALUES 
    (1, 'P001', 'John Doe', 'Jakarta', 35, '081234567890', 'Jl. Contoh No. 123', '1990-05-10', '2023-07-14', 'Islam', 'Laki-Laki', 'Ruang 101', 'Kelas 1', 'BPJS', 'Dr. Smith'),
    (2, 'P002', 'Jane Smith', 'Surabaya', 42, '082345678901', 'Jl. Percobaan No. 456', '1980-11-25', '2023-07-14', 'Kristen', 'Perempuan', 'Ruang 202', 'Kelas 2', 'Asuransi', 'Dr. Johnson'),
    (3, 'P003', 'Mark Johnson', 'Bandung', 38, '083456789012', 'Jl. Contoh No. 789', '1985-08-15', '2023-07-14', 'Katolik', 'Laki-Laki', 'Ruang 303', 'Kelas 3', 'Bayar Sendiri', 'Dr. Brown');


--
-- Indexes for dumped tables
--

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Noreg` (`Noreg`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pasien`
--
ALTER TABLE `pasien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
