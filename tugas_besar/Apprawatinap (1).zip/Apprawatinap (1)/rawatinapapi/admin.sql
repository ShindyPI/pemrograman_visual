-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2023 at 02:31 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rawatinapapi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
CREATE TABLE admin (
    `NoAdmin` VARCHAR(20) NOT NULL,
    `Nama` VARCHAR(100) NOT NULL,
    `TmptLahir` VARCHAR(100)NOT NULL,
    `Usia` INT,
    `NoTelpon` VARCHAR(20)NOT NULL,
    `Alamat` VARCHAR(200)NOT NULL,
    `TanggalLahir` date NOT NULL,
    `Agama` VARCHAR(50)NOT NULL,
    `Jkelamin` enum('L','P') NOT NULL DEFAULT 'L' ,
    `HariJaga` VARCHAR(50),
    `RuangJaga` VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--
INSERT INTO admin (`id`,`NoAdmin`, `Nama`, `TmptLahir`, `Usia`, `NoTelpon`, `Alamat`, `TanggalLahir`, `Agama`, `Jkelamin`, `HariJaga`, `RuangJaga`) VALUES 
    (1, 'A001', 'Faisal', 'Jakarta', 35, '081234567890', 'Jl. Contoh No. 123', '1990-05-10', 'Islam', 'Laki-Laki', 'Senin', 'Ruang A'),
    (2, 'A002', 'Dewi', 'Surabaya', 42, '082345678901', 'Jl. Percobaan No. 456', '1980-11-25', 'Kristen', 'Perempuan', 'Selasa', 'Ruang B'),
    (3, 'A003', 'Maritza', 'Bandung', 38, '083456789012', 'Jl. Contoh No. 789', '1985-08-15', 'Katolik', 'Laki-Laki', 'Rabu', 'Ruang C');



--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `NoAdmin` (`NoAdmin`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
