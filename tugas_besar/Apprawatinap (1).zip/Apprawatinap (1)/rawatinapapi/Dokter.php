<?php
//Simpanlah dengan nama file : Dokter.php
require_once 'database.php';
class Dokter 
{
    private $db;
    private $table = 'dokter';
    public $Nd = "";
    public $NamaDokter = "";
    public $TmptLahir = "";
    public $Usia = "";
    public $NoTelpon = "";
    public $Alamat = "";
    public $TanggalLahir = "";
    public $TglMasuk = "";
    public $Agama = "";
    public $Jkelamin = "";
    public $Spesialis = "";
    public function __construct(MySQLDatabase $db)
    {
        $this->db = $db;
    }
    public function get_all() 
    {
        $query = "SELECT * FROM $this->table";
        $result_set = $this->db->query($query);
        return $result_set;
    }
    public function get_by_id(int $id)
    {
        $query = "SELECT * FROM $this->table WHERE id = $id";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function get_by_nd(int $Nd)
    {
        $query = "SELECT * FROM $this->table WHERE nip = $Nd";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function insert(): int
    {
        $query = "INSERT INTO $this->table (`Nd`,`NamaDokter`, `TmptLahir`, `Usia`, `NoTelpon`, `Alamat`, `TanggalLahir`, `TglMasuk`, `Agama`, `Jkelamin`, `Spesialis`) VALUES ('$this->Nd','$this->NamaDokter', '$this->TmptLahir', '$this->Usia', '$this->NoTelpon', '$this->Alamat', '$this->TanggalLahir', '$this->TglMasuk', '$this->Agama', '$this->Jkelamin', '$this->Spesialis')";
        $this->db->query($query);
        return $this->db->insert_id();
    }
    public function update(int $id): int
    {
        $query = "SET `Nd`='$this->Nd', `NamaDokter` = '$this->NamaDokter', `TmptLahir` = '$this->TmptLahir', `Usia` = '$this->Usia', `NoTelpon` = '$this->NoTelpon', `Alamat` = '$this->Alamat', `TanggalLahir` = '$this->TanggalLahir', `TglMasuk` = '$this->TglMasuk', `Agama` = '$this->Agama', `Jkelamin` = '$this->Jkelamin', `Spesialis` = '$this->Spesialis'
        WHERE `id` = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function update_by_Nd($Nd): int
    {
        $query = "UPDATE $this->table SET Nd = '$this->Nd', `NamaDokter` = '$this->NamaDokter', `TmptLahir` = '$this->TmptLahir', `Usia` = '$this->Usia', `NoTelpon` = '$this->NoTelpon', `Alamat` = '$this->Alamat', `TanggalLahir` = '$this->TanggalLahir', `TglMasuk` = '$this->TglMasuk', `Agama` = '$this->Agama', `Jkelamin` = '$this->Jkelamin', `Spesialis` = '$this->Spesialis'
        WHERE `nd` = $Nd";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete(int $id): int
    {
        $query = "DELETE FROM $this->table WHERE `id` = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete_by_nd($Nd): int
    {
        $query = "DELETE FROM $this->table WHERE nd = $Nd";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
}
?>