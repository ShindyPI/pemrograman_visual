<?php
//Simpanlah dengan nama file : Admin.php
require_once 'database.php';
class Admin
{
    private $db;
    private $table = 'admin';
    public $NoAdmin = "";
    public $Nama = "";
    public $TmptLahir = "";
    public $Usia = "";
    public $NoTelpon = "";
    public $Alamat = "";
    public $TanggalLahir = "";
    public $Agama = "";
    public $Jkelamin = "";
    public $HariJaga = "";
    public $RuangJaga = "";
    public function __construct(MySQLDatabase $db)
    {
        $this->db = $db;
    }
    public function get_all() 
    {
        $query = "SELECT * FROM $this->table";
        $result_set = $this->db->query($query);
        return $result_set;
    }
    public function get_by_id(int $id)
    {
        $query = "SELECT * FROM $this->table WHERE id = $id";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function get_by_NoAdmin(int $NoAdmin)
    {
        $query = "SELECT * FROM $this->table WHERE NoAdmin = $NoAdmin";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function insert(): int
    {
        $query = "INSERT INTO $this->table (`NoAdmin`, `Nama`, `txtTmptLahir`, `Usia`, `NoTelpon`, `Alamat`, `TanggalLahir`, `Agama`, `Jkelamin`, `HariJaga`, `RuangJaga`) VALUES ('$this->NoAdmin', '$this->Nama', '$this->txtTmptLahir', '$this->Usia', '$this->NoTelpon', '$this->Alamat', '$this->TanggalLahir', '$this->Agama', '$this->Jkelamin', '$this->HariJaga', '$this->RuangJaga')";
        $this->db->query($query);
        return $this->db->insert_id();
    }
    public function update(int $id): int
    {
        $query = "SET `NoAdmin`='$this->NoAdmin', `Nama` = '$this->Nama', `TmptLahir` = '$this->TmptLahir', `Usia` = '$this->Usia', `NoTelpon` = '$this->NoTelpon', `Alamat` = '$this->Alamat', `TanggalLahir` = '$this->TanggalLahir', `TglMasuk` = '$this->TglMasuk', `Agama` = '$this->Agama', `Jkelamin` = '$this->Jkelamin', `Spesialis` = '$this->Spesialis'
        WHERE `id` = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function update_by_NoAdmin($NoAdmin): int
    {
        $query = "UPDATE $this->table SET `NoAdmin` = '$this->NoAdmin', `Nama` = '$this->Nama', `txtTmptLahir` = '$this->TmptLahir', `Usia` = '$this->Usia', `NoTelpon` = '$this->NoTelpon', `Alamat` = '$this->Alamat', `TanggalLahir` = '$this->TanggalLahir', `Agama` = '$this->Agama', `Jkelamin` = '$this->Jkelamin', `HariJaga` = '$this->HariJaga', `RuangJaga` = '$this->RuangJaga'
        WHERE `NoAdmin` = $NoAdmin";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete(int $id): int
    {
        $query = "DELETE FROM $this->table WHERE `id` = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete_by_NoAdmin ($NoAdmin): int
    {
        $query = "DELETE FROM $this->table WHERE  `NoAdmin` = $NoAdmin";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
}
?>