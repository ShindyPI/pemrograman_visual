<?php
require_once 'database.php';
require_once 'Admin.php';
$db = new MySQLDatabase();
$admin = new Admin($db);
$id=0;
$NoAdmin=0;
// Check the HTTP request method
$method = $_SERVER['REQUEST_METHOD'];
// Handle the different HTTP methods
switch ($method) {
    case 'GET':
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['NoAdmin'])){
            $NoAdmin= $_GET['NoAdmin'];
        }
        if($id>0){    
            $result = $admin->get_by_id($id);
        }elseif($NoAdmin>0){
            $result = $admin->get_by_NoAdmin($NoAdmin);
        } else {
            $result = $admin->get_all();
        }        
       
        $val = array();
        while ($row = $result->fetch_assoc()) {
            $val[] = $row;
        }
        
        header('Content-Type: application/json');
        echo json_encode($val);
        break;
    
    case 'POST':
        // Add a new admin
        $admin->NoAdmin = $_POST['NoAdmin'];
        $admin->nama = $_POST['nama'];
        $admin->tempat_lahir= $_POST['jk'];
        $admin->usia = $_POST['spesialis'];
        $admin->no_telpon = $_POST['nip'];
        $admin->alamat = $_POST['nama'];
        $admin->tanggal_lahir = $_POST['jk'];
        $admin->agama = $_POST['spesialis'];
       
        $admin->insert();
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Admin created successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Admin not created.';
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'PUT':
        // Update an existing data
        $_PUT = [];
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['NoAdmin'])){
            $NoAdmin = $_GET['NoAdmin'];
        }
        parse_str(file_get_contents("php://input"), $_PUT);
        $admin->nip = $_PUT['nip'];
        $admin->nama = $_PUT['nama'];
        $admin->jk = $_PUT['jk'];
        $admin->spesialis = $_PUT['spesialis'];
        if($id>0){    
            $admin->update($id);
        }elseif($NoAdmin<>""){
            $admin->update_by_NoAdmin($NoAdmin);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Admin updated successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Admin update failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'DELETE':
        // Delete a user
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['NoAdmin'])){
            $NoAdmin = $_GET['NoAdmin'];
        }
        if($id>0){    
            $admin->delete($id);
        }elseif($NoAdminp>0){
            $admin->delete_by_NoAdmin($NoAdmin);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Dokter deleted successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Dokter delete failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    default:
        header("HTTP/1.0 405 Method Not Allowed");
        break;
    }
$db->close()
?>