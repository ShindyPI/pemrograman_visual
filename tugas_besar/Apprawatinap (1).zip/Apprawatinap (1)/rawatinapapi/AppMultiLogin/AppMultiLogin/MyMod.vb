﻿Module MyMod
    Public rawatinapapi_folder As String = "rawatinapapi"
    Public users_api As String = "http://localhost/rawatinapapi/" & rawatinapapi_folder & "/users_api.php"
    Public Dashboard As New Form1
    Public AdminForm As New Admin
    Public DokterForm As New Dokter
    Public PasienForm As New Pasien
    Public LoginForm As New Login
    Public admin_role As Boolean = False
    Public dokter_role As Boolean = False
    Public pasien_role As Boolean = False
    Public login_valid As Boolean = False

End Module
