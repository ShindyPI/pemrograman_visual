﻿Public Class Admin
    ' Deklarasi variabel untuk menyimpan data admin
    Private Property NoAdmin As String
    Private Property NamaAdmin As String
    Private Property TempatLahir As String
    Private Property TanggalLahir As Date
    Private Property Usia As Integer
    Private Property NoTelepon As String
    Private Property Alamat As String
    Private Property Agama As String
    Private Property JenisKelamin As String
    Private Property HariJaga As String
    Private Property RuangJaga As String

    Private Sub btnSimpan_Click(sender As Object, e As EventArgs) Handles btnSimpan.Click
        ' Mengambil input dari kontrol dan menyimpannya ke variabel
        NoAdmin = txtNoAdmin.Text
        NamaAdmin = txtNama.Text
        TempatLahir = txtTmptLahir.Text
        TanggalLahir = dtpTanggalLahir.Value
        Usia = CInt(txtUsia.Text)
        NoTelepon = txtNoTelpon.Text
        Alamat = txtAlamat.Text
        Agama = cbAgama.SelectedItem.ToString()
        JenisKelamin = cbJkelamin.SelectedItem.ToString()
        HariJaga = cbHariJaga.SelectedItem.ToString()
        RuangJaga = cbRuangJaga.SelectedItem.ToString()

        ' Menampilkan data admin yang telah disimpan ke MessageBox
        Dim message As String = "Data Admin:" & vbCrLf &
            "No. Admin: " & NoAdmin & vbCrLf &
            "Nama Admin: " & NamaAdmin & vbCrLf &
            "Tempat Lahir: " & TempatLahir & vbCrLf &
            "Tanggal Lahir: " & TanggalLahir.ToShortDateString() & vbCrLf &
            "Usia: " & Usia.ToString() & vbCrLf &
            "No. Telepon: " & NoTelepon & vbCrLf &
            "Alamat: " & Alamat & vbCrLf &
            "Agama: " & Agama & vbCrLf &
            "Jenis Kelamin: " & JenisKelamin & vbCrLf &
            "Hari Jaga: " & HariJaga & vbCrLf &
            "Ruang Jaga: " & RuangJaga

        MessageBox.Show(message, "Informasi Admin")

        ' Membersihkan input setelah data disimpan
        BersihkanInput()
    End Sub

    Private Sub BersihkanInput()
        ' Mengosongkan kontrol setelah data disimpan
        txtNoAdmin.Clear()
        txtNama.Clear()
        txtTmptLahir.Clear()
        dtpTanggalLahir.Value = Date.Now
        txtUsia.Clear()
        txtNoTelpon.Clear()
        txtAlamat.Clear()
        cbAgama.SelectedIndex = -1
        cbJkelamin.SelectedIndex = -1
        cbHariJaga.SelectedIndex = -1
        cbRuangJaga.SelectedIndex = -1

        ' Mengatur fokus ke TextBox NoAdmin setelah membersihkan input
        txtNoAdmin.Focus()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Memanggil metode untuk membersihkan input
        BersihkanInput()
    End Sub

    Private Sub btnHapus_Click(sender As Object, e As EventArgs) Handles btnHapus.Click
        ' Menampilkan konfirmasi dialog sebelum menghapus data admin
        Dim result As DialogResult = MessageBox.Show("Apakah Anda yakin ingin menghapus data admin ini?", "Konfirmasi Hapus", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            ' Melakukan operasi penghapusan data admin di sini
            MessageBox.Show("Data admin telah dihapus.", "Informasi")
            BersihkanInput()
        End If
    End Sub

End Class
