﻿Public Class Users
    Public Property username As String
    Public Property passwd As String
    Public Property rolename As String
End Class
