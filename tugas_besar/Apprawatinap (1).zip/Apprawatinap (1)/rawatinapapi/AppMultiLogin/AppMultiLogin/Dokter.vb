﻿Public Class Dokter
    ' Deklarasi variabel untuk menyimpan data dokter
    Private Property Nd As String
    Private Property NamaDokter As String
    Private Property TempatLahir As String
    Private Property TanggalLahir As Date
    Private Property Usia As Integer
    Private Property NoTelepon As String
    Private Property Alamat As String
    Private Property TanggalMasuk As Date
    Private Property Agama As String
    Private Property JenisKelamin As String
    Private Property Spesialis As String

    Private Sub btnSimpan_Click(sender As Object, e As EventArgs) Handles btnSimpan.Click
        ' Mengambil input dari kontrol dan menyimpannya ke variabel
        Nd = txtNd.Text
        NamaDokter = txtNamaDokter.Text
        TempatLahir = txtTmptLahir.Text
        TanggalLahir = dtpTanggalLahir.Value
        Usia = CInt(txtUsia.Text)
        NoTelepon = txtNoTelpon.Text
        Alamat = txtAlamat.Text
        Agama = cbAgama.SelectedItem.ToString()
        JenisKelamin = cbJkelamin.SelectedItem.ToString()
        Spesialis = cbSpesialis.SelectedItem.ToString()

        ' Menampilkan data dokter yang telah disimpan ke MessageBox
        Dim message As String = "Data Dokter:" & vbCrLf &
            "No Dokter:" & Nd & vbCrLf &
            "Nama Dokter: " & NamaDokter & vbCrLf &
            "Tempat Lahir: " & TempatLahir & vbCrLf &
            "Tanggal Lahir: " & TanggalLahir.ToShortDateString() & vbCrLf &
            "Usia: " & Usia.ToString() & vbCrLf &
            "No. Telepon: " & NoTelepon & vbCrLf &
            "Alamat: " & Alamat & vbCrLf &
            "Tanggal Masuk: " & TanggalMasuk.ToShortDateString() & vbCrLf &
            "Agama: " & Agama & vbCrLf &
            "Jenis Kelamin: " & JenisKelamin & vbCrLf &
            "Spesialis: " & Spesialis

        MessageBox.Show(message, "Informasi Dokter")

        ' Membersihkan input setelah data disimpan
        BersihkanInput()
    End Sub

    Private Sub BersihkanInput()
        ' Mengosongkan kontrol setelah data disimpan
        txtNd.Clear()
        txtNamaDokter.Clear()
        txtTmptLahir.Clear()
        dtpTanggalLahir.Value = Date.Now
        txtUsia.Clear()
        txtNoTelpon.Clear()
        txtAlamat.Clear()
        cbAgama.SelectedIndex = -1
        cbJkelamin.SelectedIndex = -1
        cbSpesialis.SelectedIndex = -1

        ' Mengatur fokus ke TextBox NamaDokter setelah membersihkan input
        txtNamaDokter.Focus()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Memanggil metode untuk membersihkan input
        BersihkanInput()
    End Sub

    Private Sub btnHapus_Click(sender As Object, e As EventArgs) Handles btnHapus.Click
        ' Menampilkan konfirmasi dialog sebelum menghapus data dokter
        Dim result As DialogResult = MessageBox.Show("Apakah Anda yakin ingin menghapus data dokter ini?", "Konfirmasi Hapus", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            ' Melakukan operasi penghapusan data dokter di sini
            MessageBox.Show("Data dokter telah dihapus.", "Informasi")
            BersihkanInput()
        End If
    End Sub

End Class
