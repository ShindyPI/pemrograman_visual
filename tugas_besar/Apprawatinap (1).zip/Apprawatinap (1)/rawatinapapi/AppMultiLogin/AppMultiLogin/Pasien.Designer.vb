﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Pasien
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnSimpan = New System.Windows.Forms.Button()
        Me.txtTmptLahir = New System.Windows.Forms.TextBox()
        Me.dtpTanggalLahir = New System.Windows.Forms.DateTimePicker()
        Me.dtpTglMasuk = New System.Windows.Forms.DateTimePicker()
        Me.cbPembayaran = New System.Windows.Forms.ComboBox()
        Me.cbRuangPerawatan = New System.Windows.Forms.ComboBox()
        Me.cbDrPJawab = New System.Windows.Forms.ComboBox()
        Me.cbKlsPerawatan = New System.Windows.Forms.ComboBox()
        Me.cbAgama = New System.Windows.Forms.ComboBox()
        Me.cbJkelamin = New System.Windows.Forms.ComboBox()
        Me.txtAlamat = New System.Windows.Forms.TextBox()
        Me.txtNoTelpon = New System.Windows.Forms.TextBox()
        Me.txtUsia = New System.Windows.Forms.TextBox()
        Me.txtNamaPasien = New System.Windows.Forms.TextBox()
        Me.txtNoReg = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnHapus = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(35, 417)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(725, 196)
        Me.DataGridView1.TabIndex = 107
        '
        'btnSimpan
        '
        Me.btnSimpan.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnSimpan.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSimpan.Location = New System.Drawing.Point(294, 388)
        Me.btnSimpan.Name = "btnSimpan"
        Me.btnSimpan.Size = New System.Drawing.Size(75, 23)
        Me.btnSimpan.TabIndex = 102
        Me.btnSimpan.Text = "SIMPAN"
        Me.btnSimpan.UseVisualStyleBackColor = False
        '
        'txtTmptLahir
        '
        Me.txtTmptLahir.Location = New System.Drawing.Point(195, 181)
        Me.txtTmptLahir.Name = "txtTmptLahir"
        Me.txtTmptLahir.Size = New System.Drawing.Size(100, 20)
        Me.txtTmptLahir.TabIndex = 101
        '
        'dtpTanggalLahir
        '
        Me.dtpTanggalLahir.Location = New System.Drawing.Point(195, 151)
        Me.dtpTanggalLahir.Name = "dtpTanggalLahir"
        Me.dtpTanggalLahir.Size = New System.Drawing.Size(125, 20)
        Me.dtpTanggalLahir.TabIndex = 100
        '
        'dtpTglMasuk
        '
        Me.dtpTglMasuk.Location = New System.Drawing.Point(581, 89)
        Me.dtpTglMasuk.Name = "dtpTglMasuk"
        Me.dtpTglMasuk.Size = New System.Drawing.Size(121, 20)
        Me.dtpTglMasuk.TabIndex = 99
        '
        'cbPembayaran
        '
        Me.cbPembayaran.FormattingEnabled = True
        Me.cbPembayaran.Items.AddRange(New Object() {"Umum", "BPJS", "Asuransi", "Lainnya"})
        Me.cbPembayaran.Location = New System.Drawing.Point(581, 180)
        Me.cbPembayaran.Name = "cbPembayaran"
        Me.cbPembayaran.Size = New System.Drawing.Size(121, 21)
        Me.cbPembayaran.TabIndex = 98
        '
        'cbRuangPerawatan
        '
        Me.cbRuangPerawatan.FormattingEnabled = True
        Me.cbRuangPerawatan.Items.AddRange(New Object() {"Umum", "Intensif", "Khusus", "Bedah", "Isolasi", "Gigi", "Psikiatri", "Lainnya"})
        Me.cbRuangPerawatan.Location = New System.Drawing.Point(581, 119)
        Me.cbRuangPerawatan.Name = "cbRuangPerawatan"
        Me.cbRuangPerawatan.Size = New System.Drawing.Size(121, 21)
        Me.cbRuangPerawatan.TabIndex = 97
        '
        'cbDrPJawab
        '
        Me.cbDrPJawab.FormattingEnabled = True
        Me.cbDrPJawab.Items.AddRange(New Object() {"Dr. dr. Shindy Putri Intan", "Dr. dr. Iqbaal Dhiahfakhri R", "dr. Nisrina", "dr. Maritza", "dr. Jungwoo", "dr. Jaehyun"})
        Me.cbDrPJawab.Location = New System.Drawing.Point(581, 212)
        Me.cbDrPJawab.Name = "cbDrPJawab"
        Me.cbDrPJawab.Size = New System.Drawing.Size(147, 21)
        Me.cbDrPJawab.TabIndex = 96
        '
        'cbKlsPerawatan
        '
        Me.cbKlsPerawatan.FormattingEnabled = True
        Me.cbKlsPerawatan.Items.AddRange(New Object() {"Umum", "Khusus", "VIP", "ICU", "lainnya"})
        Me.cbKlsPerawatan.Location = New System.Drawing.Point(581, 151)
        Me.cbKlsPerawatan.Name = "cbKlsPerawatan"
        Me.cbKlsPerawatan.Size = New System.Drawing.Size(121, 21)
        Me.cbKlsPerawatan.TabIndex = 95
        '
        'cbAgama
        '
        Me.cbAgama.FormattingEnabled = True
        Me.cbAgama.Items.AddRange(New Object() {"Islam", "Kristen", "Hindu", "Budha", "Lainnya"})
        Me.cbAgama.Location = New System.Drawing.Point(195, 209)
        Me.cbAgama.Name = "cbAgama"
        Me.cbAgama.Size = New System.Drawing.Size(100, 21)
        Me.cbAgama.TabIndex = 94
        '
        'cbJkelamin
        '
        Me.cbJkelamin.FormattingEnabled = True
        Me.cbJkelamin.Items.AddRange(New Object() {"Laki-laki", "Perempuan"})
        Me.cbJkelamin.Location = New System.Drawing.Point(195, 272)
        Me.cbJkelamin.Name = "cbJkelamin"
        Me.cbJkelamin.Size = New System.Drawing.Size(100, 21)
        Me.cbJkelamin.TabIndex = 93
        '
        'txtAlamat
        '
        Me.txtAlamat.Location = New System.Drawing.Point(195, 343)
        Me.txtAlamat.Name = "txtAlamat"
        Me.txtAlamat.Size = New System.Drawing.Size(200, 20)
        Me.txtAlamat.TabIndex = 92
        '
        'txtNoTelpon
        '
        Me.txtNoTelpon.Location = New System.Drawing.Point(195, 308)
        Me.txtNoTelpon.Name = "txtNoTelpon"
        Me.txtNoTelpon.Size = New System.Drawing.Size(125, 20)
        Me.txtNoTelpon.TabIndex = 91
        '
        'txtUsia
        '
        Me.txtUsia.Location = New System.Drawing.Point(195, 241)
        Me.txtUsia.Name = "txtUsia"
        Me.txtUsia.Size = New System.Drawing.Size(46, 20)
        Me.txtUsia.TabIndex = 90
        '
        'txtNamaPasien
        '
        Me.txtNamaPasien.Location = New System.Drawing.Point(195, 120)
        Me.txtNamaPasien.Name = "txtNamaPasien"
        Me.txtNamaPasien.Size = New System.Drawing.Size(200, 20)
        Me.txtNamaPasien.TabIndex = 89
        '
        'txtNoReg
        '
        Me.txtNoReg.Location = New System.Drawing.Point(195, 89)
        Me.txtNoReg.Name = "txtNoReg"
        Me.txtNoReg.Size = New System.Drawing.Size(46, 20)
        Me.txtNoReg.TabIndex = 88
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(57, 218)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(40, 13)
        Me.Label15.TabIndex = 87
        Me.Label15.Text = "Agama"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(451, 220)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(116, 13)
        Me.Label14.TabIndex = 86
        Me.Label14.Text = "Dr Penanggung Jawab"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(451, 188)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(66, 13)
        Me.Label13.TabIndex = 85
        Me.Label13.Text = "Pembayaran"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(451, 159)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(87, 13)
        Me.Label12.TabIndex = 84
        Me.Label12.Text = "Kelas Perawatan"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(451, 128)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(93, 13)
        Me.Label11.TabIndex = 83
        Me.Label11.Text = "Ruang Perawatan"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(451, 97)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(84, 13)
        Me.Label10.TabIndex = 82
        Me.Label10.Text = "Tanggal Masuk "
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(58, 316)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(60, 13)
        Me.Label9.TabIndex = 81
        Me.Label9.Text = "No. Telpon"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(58, 281)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(71, 13)
        Me.Label8.TabIndex = 80
        Me.Label8.Text = "Jenis Kelamin"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(58, 351)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(39, 13)
        Me.Label7.TabIndex = 79
        Me.Label7.Text = "Alamat"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(58, 249)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 13)
        Me.Label6.TabIndex = 78
        Me.Label6.Text = "Usia"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(57, 188)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(69, 13)
        Me.Label5.TabIndex = 77
        Me.Label5.Text = "Tempat Lahir"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(57, 159)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(72, 13)
        Me.Label4.TabIndex = 76
        Me.Label4.Text = "Tanggal Lahir"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(57, 128)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(70, 13)
        Me.Label3.TabIndex = 75
        Me.Label3.Text = "Nama Pasien"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(57, 97)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(70, 13)
        Me.Label16.TabIndex = 74
        Me.Label16.Text = "No.Registrasi"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Teal
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Location = New System.Drawing.Point(35, 16)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(725, 50)
        Me.Panel1.TabIndex = 73
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(141, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(384, 39)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Pendaftaran Rawat Inap"
        '
        'Panel2
        '
        Me.Panel2.Location = New System.Drawing.Point(36, 73)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(724, 309)
        Me.Panel2.TabIndex = 108
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 30.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(25, 140)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 46)
        Me.Label1.TabIndex = 72
        '
        'btnHapus
        '
        Me.btnHapus.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnHapus.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnHapus.Location = New System.Drawing.Point(375, 388)
        Me.btnHapus.Name = "btnHapus"
        Me.btnHapus.Size = New System.Drawing.Size(75, 23)
        Me.btnHapus.TabIndex = 109
        Me.btnHapus.Text = "HAPUS"
        Me.btnHapus.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnClear.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnClear.Location = New System.Drawing.Point(456, 388)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 106
        Me.btnClear.Text = "CLEAR"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'Pasien
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(801, 634)
        Me.Controls.Add(Me.btnHapus)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnSimpan)
        Me.Controls.Add(Me.txtTmptLahir)
        Me.Controls.Add(Me.dtpTanggalLahir)
        Me.Controls.Add(Me.dtpTglMasuk)
        Me.Controls.Add(Me.cbPembayaran)
        Me.Controls.Add(Me.cbRuangPerawatan)
        Me.Controls.Add(Me.cbDrPJawab)
        Me.Controls.Add(Me.cbKlsPerawatan)
        Me.Controls.Add(Me.cbAgama)
        Me.Controls.Add(Me.cbJkelamin)
        Me.Controls.Add(Me.txtAlamat)
        Me.Controls.Add(Me.txtNoTelpon)
        Me.Controls.Add(Me.txtUsia)
        Me.Controls.Add(Me.txtNamaPasien)
        Me.Controls.Add(Me.txtNoReg)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Pasien"
        Me.Text = "Pasien"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnSimpan As Button
    Friend WithEvents txtTmptLahir As TextBox
    Friend WithEvents dtpTanggalLahir As DateTimePicker
    Friend WithEvents dtpTglMasuk As DateTimePicker
    Friend WithEvents cbPembayaran As ComboBox
    Friend WithEvents cbRuangPerawatan As ComboBox
    Friend WithEvents cbDrPJawab As ComboBox
    Friend WithEvents cbKlsPerawatan As ComboBox
    Friend WithEvents cbAgama As ComboBox
    Friend WithEvents cbJkelamin As ComboBox
    Friend WithEvents txtAlamat As TextBox
    Friend WithEvents txtNoTelpon As TextBox
    Friend WithEvents txtUsia As TextBox
    Friend WithEvents txtNamaPasien As TextBox
    Friend WithEvents txtNoReg As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents btnHapus As Button
    Friend WithEvents btnClear As Button
End Class
