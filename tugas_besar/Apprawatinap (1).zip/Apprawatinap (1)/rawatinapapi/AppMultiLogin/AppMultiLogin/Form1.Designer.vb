﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoginBar = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutBar = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitBar = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuAdminBar = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormAdminToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuDokterBar = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormDokterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuPasienBar = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormPasienToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Maroon
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.MenuAdminBar, Me.MenuDokterBar, Me.MenuPasienBar})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(387, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoginBar, Me.LogoutBar, Me.ExitBar})
        Me.FileToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'LoginBar
        '
        Me.LoginBar.Name = "LoginBar"
        Me.LoginBar.Size = New System.Drawing.Size(180, 22)
        Me.LoginBar.Text = "Login"
        '
        'LogoutBar
        '
        Me.LogoutBar.Name = "LogoutBar"
        Me.LogoutBar.Size = New System.Drawing.Size(180, 22)
        Me.LogoutBar.Text = "Logout"
        '
        'ExitBar
        '
        Me.ExitBar.Name = "ExitBar"
        Me.ExitBar.Size = New System.Drawing.Size(180, 22)
        Me.ExitBar.Text = "Exit"
        '
        'MenuAdminBar
        '
        Me.MenuAdminBar.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FormAdminToolStripMenuItem})
        Me.MenuAdminBar.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.MenuAdminBar.Name = "MenuAdminBar"
        Me.MenuAdminBar.Size = New System.Drawing.Size(89, 20)
        Me.MenuAdminBar.Text = "Menu Admin"
        '
        'FormAdminToolStripMenuItem
        '
        Me.FormAdminToolStripMenuItem.Name = "FormAdminToolStripMenuItem"
        Me.FormAdminToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.FormAdminToolStripMenuItem.Text = "Form Admin"
        '
        'MenuDokterBar
        '
        Me.MenuDokterBar.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FormDokterToolStripMenuItem})
        Me.MenuDokterBar.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.MenuDokterBar.Name = "MenuDokterBar"
        Me.MenuDokterBar.Size = New System.Drawing.Size(88, 20)
        Me.MenuDokterBar.Text = "Menu Dokter"
        '
        'FormDokterToolStripMenuItem
        '
        Me.FormDokterToolStripMenuItem.Name = "FormDokterToolStripMenuItem"
        Me.FormDokterToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.FormDokterToolStripMenuItem.Text = "Form Dokter"
        '
        'MenuPasienBar
        '
        Me.MenuPasienBar.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FormPasienToolStripMenuItem})
        Me.MenuPasienBar.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.MenuPasienBar.Name = "MenuPasienBar"
        Me.MenuPasienBar.Size = New System.Drawing.Size(87, 20)
        Me.MenuPasienBar.Text = "Menu Pasien"
        '
        'FormPasienToolStripMenuItem
        '
        Me.FormPasienToolStripMenuItem.Name = "FormPasienToolStripMenuItem"
        Me.FormPasienToolStripMenuItem.Size = New System.Drawing.Size(139, 22)
        Me.FormPasienToolStripMenuItem.Text = "Form Pasien"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(387, 150)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LoginBar As ToolStripMenuItem
    Friend WithEvents LogoutBar As ToolStripMenuItem
    Friend WithEvents MenuAdminBar As ToolStripMenuItem
    Friend WithEvents FormAdminToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MenuDokterBar As ToolStripMenuItem
    Friend WithEvents FormDokterToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MenuPasienBar As ToolStripMenuItem
    Friend WithEvents FormPasienToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitBar As ToolStripMenuItem
End Class
