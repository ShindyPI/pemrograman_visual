<?php
//Simpanlah dengan nama file : Pasien.php
require_once 'database.php';
class Pasien 
{
    private $db;
    private $table = 'pasien';
    public $Noreg = "";
    public $NamaPasien = "";
    public $TmptLahir = "";
    public $Usia = "";
    public $NoTelpon = "";
    public $Alamat = "";
    public $TanggalLahir = "";
    public $dtpTglMasuk = "";
    public $Agama = "";
    public $Jkelamin = "";
    public $RuangPerawatan = "";
    public $KlsPerawatan = "";
    public $Pembayaran = "";
    public $DrPJawab = "";
    public $kota = "";
    public function __construct(MySQLDatabase $db)
    {
        $this->db = $db;
    }
    public function get_all() 
    {
        $query = "SELECT * FROM $this->table";
        $result_set = $this->db->query($query);
        return $result_set;
    }
    public function get_by_id(int $id)
    {
        $query = "SELECT * FROM $this->table WHERE id = $id";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function get_by_noreg(int $Noreg)
    {
        $query = "SELECT * FROM $this->table WHERE noreg = $Noreg";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function insert(): int
    {
        $query = "INSERT INTO $this->table (`Noreg`, `NamaPasien`, `TmptLahir`, `Usia`, `NoTelpon`, `Alamat`, `TanggalLahir`, `dtpTglMasuk`, `Agama`, `Jkelamin`, `RuangPerawatan`, `KlsPerawatan`, `Pembayaran`, `DrPJawab`) VALUES ('$this->Noreg', '$this->NamaPasien', '$this->TmptLahir', '$this->Usia', '$this->NoTelpon', '$this->Alamat', '$this->TanggalLahir', '$this->dtpTglMasuk', '$this->Agama', '$this->Jkelamin', '$this->RuangPerawatan', '$this->KlsPerawatan', '$this->Pembayaran', '$this->DrPJawab')";
        $this->db->query($query);
        return $this->db->insert_id();
    }
    public function update(int $id): int
    {
        $query = "UPDATE $this->table 
        SET `Noreg` = '$this->Noreg', `NamaPasien` = '$this->NamaPasien', `TmptLahir` = '$this->TmptLahir', `Usia` = '$this->Usia', `NoTelpon` = '$this->NoTelpon', `Alamat` = '$this->Alamat', `TanggalLahir` = '$this->TanggalLahir', `dtpTglMasuk` = '$this->dtpTglMasuk', `Agama` = '$this->Agama', `Jkelamin` = '$this->Jkelamin', `RuangPerawatan` = '$this->RuangPerawatan', `KlsPerawatan` = '$this->KlsPerawatan', `Pembayaran` = '$this->Pembayaran', `DrPJawab` = '$this->DrPJawab'
        WHERE `id` = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function update_by_noreg ($Noreg): int
    {
        $query = "UPDATE $this->table 
        SET `Noreg` = '$this->Noreg', `NamaPasien` = '$this->NamaPasien', `TmptLahir` = '$this->TmptLahir', `Usia` = '$this->Usia', `NoTelpon` = '$this->NoTelpon', `Alamat` = '$this->Alamat', `TanggalLahir` = '$this->TanggalLahir', `dtpTglMasuk` = '$this->dtpTglMasuk', `Agama` = '$this->Agama', `Jkelamin` = '$this->Jkelamin', `RuangPerawatan` = '$this->RuangPerawatan', `KlsPerawatan` = '$this->KlsPerawatan', `Pembayaran` = '$this->Pembayaran', `DrPJawab` = '$this->DrPJawab'
        WHERE `Noreg` = $Noreg";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete($id): int
    {
        $query = "DELETE FROM $this->table WHERE `id` = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    
    }
    public function delete_by_noreg($Noreg): int
    {
        $query = "DELETE FROM $this->table WHERE nip = $Noreg";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
}
?>