﻿Public Class Rawatinap
    Public Property nrp As String
    Public Property nama As String
    Public Property tanggal_masuk As String
    Public Property no_kamar As String
    Public Property diagnosa As String
    Public Property nama_dokter As String

End Class
