﻿Module MyMod
    Public api_folder As String = "apprawatinap"
    Public users_api As String = "http://a0837446.xsph.ru/" & api_folder & "/users_api.php"
    Public pasien_api As String = "http://a0837446.xsph.ru/" & api_folder & "/pasien_api.php"
    Public rawatinap_api As String = "http://a0837446.xsph.ru/" & api_folder & "/rawatinap_api.php"
    Public dokter_api As String = "http://a0837446.xsph.ru/" & api_folder & "/dokter_api.php"
    Public dokter_role As Boolean = False
    Public pasien_role As Boolean = False
    Public rawatinap_role As Boolean = False
End Module
